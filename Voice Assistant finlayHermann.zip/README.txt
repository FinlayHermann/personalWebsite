This is coded by Finlay Hermann.
It is for free use and can be copied it isn't finished yet.
To change the Language change line 15 'de' to your language
and 'de-de' in line 26. also replace the questions and operations
to your language and so on.