import threading
import time
import os
import sys
import speech_recognition as sr
import pyttsx3
import wikipedia
import webbrowser
import requests
from bs4 import BeautifulSoup

engine = pyttsx3.init()
global listening
listening = False
wikipedia.set_lang('de')


def parse_command():
    listener = sr.Recognizer()

    with sr.Microphone() as source:
        listener.pause_threshold = 0.5
        input_speech = listener.listen(source)

    try:
        query = listener.recognize_google(input_speech, language='de-de')
        print(f'The input speech was: {query}')
    except Exception as exception:
        return None

    return query


def search_web(phrase: str):
    if 'wetter' in phrase.split():
        link = 'https://www.google.com/search?q=' + '+'.join(phrase.split())
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 OPR/105.0.0.0"
        }
        response = requests.get(url=link, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")
        temp = soup.find(class_='wob_t q8U8x').text
        ns = soup.find(attrs={'id': 'wob_pp'}).text
        lft = soup.find(attrs={'id': 'wob_hm'}).text
        wind = soup.find(attrs={'id': 'wob_ws'}).text
        cl = soup.find(attrs={'id': 'wob_dc'}).text

        return (f"Es werden {temp} grad mit {ns} Niederschlag und einer {lft} Luftfeuchtigkeit. " +
                f"Es kommt zu Windgeschwindigkeiten von {wind} und es wird {cl}")

    else:
        link = 'https://www.google.com/search?q=' + '+'.join(phrase.split())
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 OPR/105.0.0.0"
        }
        response = requests.get(url=link, headers=headers)
        soup = BeautifulSoup(response.text, features="html.parser")
        answer = soup.find(class_='hgKElc')
        if answer is None:
            answer = soup.find(class_='gsrt vk_bk FzvWSb YwPhnf')
        if answer is None:
            searchResults = wikipedia.search(query)
            try:
                wikiPage = wikipedia.page(searchResults[0])
            except wikipedia.DisambiguationError as error:
                wikiPage = wikipedia.page(error.options[0])
            wikiSummary = str(wikiPage.summary)
            return wikiSummary
        if answer is None:
            return None
        else:
            return answer.text


def speak(msg):
    engine.say(msg)
    engine.runAndWait()


while True:
    query = parse_command()
    if query:
        query = query.lower().split()

        if listening:
            listening = False

            questions = ['wie', 'wer', 'was', 'wieso', 'weshalb', 'warum', 'wo', 'wodurch']
            operations = ['öffne', 'schließe', 'schreibe', 'rechne', 'entscheide', 'starte']
            days = ['montag', 'dienstag', 'mittwoch', 'donnerstag']
            if query[0] in questions:
                answer = search_web(' '.join(query))

                if answer:
                    thread = threading.Thread(target=speak, args=(answer,))
                    thread.start()

                else:
                    thread = threading.Thread(target=speak, args=("Ich habe keine Ergebnisse gefunden.",))
                    thread.start()

                # if query[-1] == 'handy':
                    # print('on phone')

            elif query[0] in operations:
                print('Operation')
                # if query[-1] == 'handy':
                #   execute on phone
                #   print('on phone')

        if query[0] == 'computer':
            listening = True
            thread = (threading.Thread(target=speak, args=('Computer hört.',)))
            thread.run()


            def listen():
                global listening
                time.sleep(7)
                listening = False

            threading.Thread(target=listen).start()

        elif query[0] == 'stopp':
            python = sys.executable
            os.execl(python, python, *sys.argv)
