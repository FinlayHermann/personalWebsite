This was coded by Finlay Hermann.
It is free to be copied and used.
It is a Colorpicker to translate and comparte colors from hex to rgb and reverse.
It is recomended to use this on a Phone as it was made originaly with Pydroid3.