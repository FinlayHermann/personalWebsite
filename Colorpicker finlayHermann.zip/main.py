import tkinter as tk

Color = "#000000"

global Var1
global Var2
global Var3
Var1 = 0
Var2 = 0
Var3 = 0

global hexVar1
global hexVar2
global hexVar3
hexVar1 = "00"
hexVar2 = "00"
hexVar3 = "00"

global SplitB
SplitB = False


def hex(Input):
    if (Input % 16) <= 9:
        Out2 = Input % 16
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 10:
        Out2 = "a"
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 11:
        Out2 = "b"
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 12:
        Out2 = "c"
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 13:
        Out2 = "d"
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 14:
        Out2 = "e"
        Out1Pre = (Input - (Input % 16)) / 16

    elif (Input % 16) == 15:
        Out2 = "f"
        Out1Pre = (Input - (Input % 16)) / 16

    if Out1Pre <= 9:
        Out1 = int(Out1Pre)

    elif Out1Pre == 10:
        Out1 = "a"

    elif Out1Pre == 11:
        Out1 = "b"

    elif Out1Pre == 12:
        Out1 = "c"

    elif Out1Pre == 13:
        Out1 = "d"

    elif Out1Pre == 14:
        Out1 = "e"

    elif Out1Pre == 15:
        Out1 = "f"

    Output = str(Out1) + str(Out2)
    return Output


def Blue():
    global Var3
    global hexVar1
    global hexVar2
    global hexVar3

    Var3 = Var3 + int(EntryMult.get())
    if Var3 > 255:
        Var3 = 255
    elif Var3 < 0:
        Var3 = 0

    hexVar3 = hex(int(Var3))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def BlueM():
    global Var3
    global hexVar1
    global hexVar2
    global hexVar3

    Var3 = Var3 - int(EntryMult.get())
    if Var3 > 255:
        Var3 = 255
    elif Var3 < 0:
        Var3 = 0

    hexVar3 = hex(int(Var3))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def Green():
    global Var2
    global hexVar1
    global hexVar2
    global hexVar3

    Var2 = Var2 + int(EntryMult.get())
    if Var2 > 255:
        Var2 = 255
    elif Var2 < 0:
        Var2 = 0

    hexVar2 = hex(int(Var2))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def GreenM():
    global Var2
    global hexVar1
    global hexVar2
    global hexVar3

    Var2 = Var2 - int(EntryMult.get())
    if Var2 > 255:
        Var2 = 255
    elif Var2 < 0:
        Var2 = 0

    hexVar2 = hex(int(Var2))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def Red():
    global Var1
    global hexVar1
    global hexVar2
    global hexVar3

    Var1 = Var1 + int(EntryMult.get())
    if Var1 > 255:
        Var1 = 255
    elif Var1 < 0:
        Var1 = 0

    hexVar1 = hex(int(Var1))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def RedM():
    global Var1
    global hexVar1
    global hexVar2
    global hexVar3

    Var1 = Var1 - int(EntryMult.get())
    if Var1 > 255:
        Var1 = 255
    elif Var1 < 0:
        Var1 = 0

    hexVar1 = hex(int(Var1))
    Color = "#" + str(hexVar1) + str(hexVar2) + str(hexVar3)

    Update(Color)


def Update(Color):
    global Var1
    global Var2
    global Var3

    global SplitB

    RedL.configure(text=Var1)
    GreenL.configure(text=Var2)
    BlueL.configure(text=Var3)

    Colorpicker.configure(bg=Color)
    if SplitB == False:
        Colorpicker2.configure(bg=Color)

    Clear()
    HexEnt.insert(0, Color)


def Clear():
    while len(HexEnt.get()) > 0:
        HexEnt.delete(0)


def ClearB():
    while len(HexEnt.get()) > 0:
        HexEnt.delete(0)

    HexEnt.insert(0, "#")
    Colorpicker.configure(bg="#000000")
    Colorpicker2.configure(bg="#000000")


def Submit():
    global Var1
    global Var2
    global Var3
    global hexVar1
    global hexVar2
    global hexVar3

    if len(str(HexEnt.get())) == 7:
        Color = str(HexEnt.get())
        List = list(HexEnt.get())

        Var1 = (GetNum(List[1]) * 16) + GetNum(List[2])
        Var2 = (GetNum(List[3]) * 16) + GetNum(List[4])
        Var3 = (GetNum(List[5]) * 16) + GetNum(List[6])

        hexVar1 = str(List[1]) + str(List[2])
        hexVar2 = str(List[3]) + str(List[4])
        hexVar3 = str(List[5]) + str(List[6])

        Update(Color)


def GetNum(Hex):
    if Hex == "a":
        return 10

    elif Hex == "b":
        return 11

    elif Hex == "c":
        return 12

    elif Hex == "d":
        return 13

    elif Hex == "e":
        return 14

    elif Hex == "f":
        return 15

    else:
        return int(Hex)


def Split():
    global SplitB

    if SplitB == True:
        SplitB = False
        Split.configure(bg="red")
        Update(HexEnt.get())

    else:
        SplitB = True
        Split.configure(bg="green")


w = tk.Tk()
w.configure(bg="grey")

CFrame = tk.Frame(bg="grey")

Colorpicker = tk.Label(CFrame, fg="white", bg=Color)
Colorpicker.pack(side="right", fill="both", expand=True)

Colorpicker2 = tk.Label(CFrame, fg="white", bg=Color)
Colorpicker2.pack(side="left", fill="both", expand=True)

CFrame.pack(padx="30", pady="30", fill="both", expand=True)

LabelMult = tk.Label(text="Multiplier:", bg="grey")
LabelMult.pack(pady="5", padx="5")

EntryMult = tk.Entry(justify="center")
EntryMult.pack()
EntryMult.insert(0, 1)

UGUI = tk.Frame(bg="grey")

RedFrame = tk.Frame(UGUI, bg="red")

RedL = tk.Label(RedFrame, text=Var1, bg="red")
RedL.pack(pady="5")

RedButton = tk.Button(RedFrame, text="+", command=Red)
RedButton.pack(pady="5", padx="5", fill="x")

RedButtonM = tk.Button(RedFrame, text="-", command=RedM)
RedButtonM.pack(pady="5", padx="5", fill="x")

RedFrame.pack(padx="5", side="left", anchor="w", fill="x", expand=True)

GreenFrame = tk.Frame(UGUI, bg="green")

GreenL = tk.Label(GreenFrame, text=Var2, bg="green")
GreenL.pack(pady="5")

GreenButton = tk.Button(GreenFrame, text="+", command=Green)
GreenButton.pack(pady="5", padx="5", fill="x")

GreenButtonM = tk.Button(GreenFrame, text="-", command=GreenM)
GreenButtonM.pack(pady="5", padx="5", fill="x")

GreenFrame.pack(side="left", anchor="center", fill="x", expand=True)

BlueFrame = tk.Frame(UGUI, bg="blue")

BlueL = tk.Label(BlueFrame, text=Var3, bg="blue")
BlueL.pack(pady="5")

BlueButton = tk.Button(BlueFrame, text="+", command=Blue)
BlueButton.pack(pady="5", padx="5", fill="x")

BlueButtonM = tk.Button(BlueFrame, text="-", command=BlueM)
BlueButtonM.pack(pady="5", padx="5", fill="x")

BlueFrame.pack(padx="5", anchor="s", side="right", fill="x", expand=True)

UGUI.pack(fill="x", pady="30")

EntryF = tk.Frame(bg="grey")

HexTXT = tk.Label(EntryF, text="Hexcode:", bg="grey")
HexTXT.pack(pady="5")

HexEnt = tk.Entry(EntryF, justify="center")
HexEnt.pack(side="left", fill="both")
HexEnt.insert(0, Color)

XButton = tk.Button(EntryF, text="X", highlightthickness="3", highlightbackground="black", command=ClearB)
XButton.pack(side="left")

EntryF.pack(padx="5", pady="5")

Submit = tk.Button(text="Submit", highlightthickness="0", bg="#286528", activebackground="#286528", fg="black",
                   activeforeground="white", command=Submit)
Submit.pack(fill="x", pady="10", padx="225")

Split = tk.Button(text="Keep Color", bg="red", command=Split)
Split.pack(pady="10")

w.mainloop()